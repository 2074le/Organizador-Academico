package com.example.gestionacademica
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp


class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {

            MaterialTheme {

                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFFFFFFFF)
                ) {

                    App()

                }
            }
        }
    }
}


@Composable
fun App() {

    var mostrarRegistro by remember {
        mutableStateOf(false)
    }

    if (mostrarRegistro) {

        RegistroScreen(
            volverLogin = {
                mostrarRegistro = false
            }
        )

    } else {

        LoginScreen(
            irRegistro = {
                mostrarRegistro = true
            }
        )
    }
}


@Composable
fun LoginScreen(
    irRegistro: () -> Unit
) {

    var correo by remember {
        mutableStateOf("")
    }

    var contrasena by remember {
        mutableStateOf("")
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(30.dp),

        horizontalAlignment = Alignment.CenterHorizontally,

        verticalArrangement = Arrangement.Center
    ) {

        Text(
            text = "Estudia+",
            fontSize = 40.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF2563EB)
        )

        Spacer(
            modifier = Modifier.height(10.dp)
        )

        Text(
            text = "Organiza tu estudio y alcanza tus metas",
            fontSize = 16.sp,
            color = Color.Gray
        )

        Spacer(
            modifier = Modifier.height(40.dp)
        )

        Text(
            text = "¡Hola de nuevo! 👋",
            fontSize = 26.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(
            modifier = Modifier.height(25.dp)
        )

        OutlinedTextField(
            value = correo,

            onValueChange = {
                correo = it
            },

            modifier = Modifier.fillMaxWidth(),

            label = {
                Text("Correo electrónico")
            },

            placeholder = {
                Text("ejemplo@correo.com")
            },

            singleLine = true,

            shape = RoundedCornerShape(12.dp)
        )

        Spacer(
            modifier = Modifier.height(15.dp)
        )

        OutlinedTextField(
            value = contrasena,

            onValueChange = {
                contrasena = it
            },

            modifier = Modifier.fillMaxWidth(),

            label = {
                Text("Contraseña")
            },

            singleLine = true,

            visualTransformation = PasswordVisualTransformation(),

            shape = RoundedCornerShape(12.dp)
        )

        Spacer(
            modifier = Modifier.height(5.dp)
        )

        TextButton(
            onClick = {

            },

            modifier = Modifier.align(Alignment.End)
        ) {

            Text(
                text = "¿Olvidaste tu contraseña?",
                color = Color(0xFF2563EB)
            )
        }

        Spacer(
            modifier = Modifier.height(10.dp)
        )

        Button(
            onClick = {

            },

            modifier = Modifier
                .fillMaxWidth()
                .height(55.dp),

            shape = RoundedCornerShape(12.dp)
        ) {

            Text(
                text = "Iniciar sesión",
                fontSize = 17.sp
            )
        }

        Spacer(
            modifier = Modifier.height(25.dp)
        )

        Text(
            text = "¿No tienes una cuenta?",
            fontSize = 15.sp
        )

        TextButton(
            onClick = {
                irRegistro()
            }
        ) {

            Text(
                text = "Registrarse",
                color = Color(0xFF2563EB),
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
        }
    }
}


@Composable
fun RegistroScreen(
    volverLogin: () -> Unit
) {

    var nombre by remember {
        mutableStateOf("")
    }

    var correo by remember {
        mutableStateOf("")
    }

    var contrasena by remember {
        mutableStateOf("")
    }

    var confirmarContrasena by remember {
        mutableStateOf("")
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(30.dp),

        horizontalAlignment = Alignment.CenterHorizontally,

        verticalArrangement = Arrangement.Center
    ) {

        Text(
            text = "Crear cuenta",
            fontSize = 30.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF2563EB)
        )

        Spacer(
            modifier = Modifier.height(8.dp)
        )

        Text(
            text = "Comienza a organizar tu estudio",
            fontSize = 16.sp,
            color = Color.Gray
        )

        Spacer(
            modifier = Modifier.height(25.dp)
        )

        OutlinedTextField(
            value = nombre,

            onValueChange = {
                nombre = it
            },

            modifier = Modifier.fillMaxWidth(),

            label = {
                Text("Nombre completo")
            },

            singleLine = true,

            shape = RoundedCornerShape(12.dp)
        )

        Spacer(
            modifier = Modifier.height(12.dp)
        )

        OutlinedTextField(
            value = correo,

            onValueChange = {
                correo = it
            },

            modifier = Modifier.fillMaxWidth(),

            label = {
                Text("Correo electrónico")
            },

            singleLine = true,

            shape = RoundedCornerShape(12.dp)
        )

        Spacer(
            modifier = Modifier.height(12.dp)
        )

        OutlinedTextField(
            value = contrasena,

            onValueChange = {
                contrasena = it
            },

            modifier = Modifier.fillMaxWidth(),

            label = {
                Text("Contraseña")
            },

            singleLine = true,

            visualTransformation = PasswordVisualTransformation(),

            shape = RoundedCornerShape(12.dp)
        )

        Spacer(
            modifier = Modifier.height(12.dp)
        )

        OutlinedTextField(
            value = confirmarContrasena,

            onValueChange = {
                confirmarContrasena = it
            },

            modifier = Modifier.fillMaxWidth(),

            label = {
                Text("Confirmar contraseña")
            },

            singleLine = true,

            visualTransformation = PasswordVisualTransformation(),

            shape = RoundedCornerShape(12.dp)
        )

        Spacer(
            modifier = Modifier.height(22.dp)
        )

        Button(
            onClick = {

            },

            modifier = Modifier
                .fillMaxWidth()
                .height(55.dp),

            shape = RoundedCornerShape(12.dp)
        ) {

            Text(
                text = "Crear cuenta",
                fontSize = 17.sp
            )
        }

        Spacer(
            modifier = Modifier.height(15.dp)
        )

        TextButton(
            onClick = {
                volverLogin()
            }
        ) {

            Text(
                text = "¿Ya tienes una cuenta? Iniciar sesión",
                color = Color(0xFF2563EB)
            )
        }
    }
}